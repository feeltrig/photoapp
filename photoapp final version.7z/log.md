<!--  version log -->

<!-- unables -->

1. cannot fetch image from localstorage

<!-- comlpleted v1.0.9 -->

1. create navbar, footer and appstate
2. create routing
3. create register and login forms
4. create user auth from local storage
5. set state in localstorage and able to upload profile photo
6. fetch all images and do pagination
7. create contact us submit form
8. force user registration/login

<!-- v1.0.10 -->

5. get icon for logout with userphoto or image
6. images filteration

<!-- v1.0.11 -->

3. add logo to header
4. show modal for succesfully sent query
5. fetch from api to show images
6. set header completely functional
7. better folder structure
